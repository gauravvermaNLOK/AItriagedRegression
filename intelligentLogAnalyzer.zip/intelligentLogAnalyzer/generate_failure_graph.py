"""
Generates failure pattern graphs from Karate triage data.
"""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime
from collections import defaultdict

# Raw data from Athena query results (deduplicated to unique runs per day)
raw_data = [
    # Scenario 04 - Always Failing
    ("04_Logic_Failure_Boolean_Mismatch", "2026-04-25 16:03:29", "FAILED"),
    ("04_Logic_Failure_Boolean_Mismatch", "2026-04-26 15:12:57", "FAILED"),
    ("04_Logic_Failure_Boolean_Mismatch", "2026-04-26 15:57:04", "FAILED"),
    ("04_Logic_Failure_Boolean_Mismatch", "2026-04-27 12:01:11", "FAILED"),
    ("04_Logic_Failure_Boolean_Mismatch", "2026-04-27 12:33:57", "FAILED"),
    ("04_Logic_Failure_Boolean_Mismatch", "2026-04-27 13:04:46", "FAILED"),
    ("04_Logic_Failure_Boolean_Mismatch", "2026-04-30 14:14:43", "FAILED"),
    ("04_Logic_Failure_Boolean_Mismatch", "2026-04-30 14:21:46", "FAILED"),
    ("04_Logic_Failure_Boolean_Mismatch", "2026-05-01 21:36:34", "FAILED"),
    ("04_Logic_Failure_Boolean_Mismatch", "2026-05-01 21:47:52", "FAILED"),
    # Scenario 05 - Always Failing
    ("05_Schema_Drift_Failure", "2026-04-25 16:03:29", "FAILED"),
    ("05_Schema_Drift_Failure", "2026-04-26 15:12:57", "FAILED"),
    ("05_Schema_Drift_Failure", "2026-04-26 15:57:05", "FAILED"),
    ("05_Schema_Drift_Failure", "2026-04-27 12:01:12", "FAILED"),
    ("05_Schema_Drift_Failure", "2026-04-27 12:33:58", "FAILED"),
    ("05_Schema_Drift_Failure", "2026-04-27 13:04:46", "FAILED"),
    ("05_Schema_Drift_Failure", "2026-04-30 14:14:44", "FAILED"),
    ("05_Schema_Drift_Failure", "2026-04-30 14:21:46", "FAILED"),
    ("05_Schema_Drift_Failure", "2026-05-01 21:36:35", "FAILED"),
    ("05_Schema_Drift_Failure", "2026-05-01 21:47:53", "FAILED"),
    # Scenario 07 - Always Failing
    ("07_Boundary_Value_Assertion", "2026-04-25 16:03:30", "FAILED"),
    ("07_Boundary_Value_Assertion", "2026-04-26 15:12:58", "FAILED"),
    ("07_Boundary_Value_Assertion", "2026-04-26 15:57:06", "FAILED"),
    ("07_Boundary_Value_Assertion", "2026-04-27 12:01:13", "FAILED"),
    ("07_Boundary_Value_Assertion", "2026-04-27 12:33:59", "FAILED"),
    ("07_Boundary_Value_Assertion", "2026-04-27 13:04:48", "FAILED"),
    ("07_Boundary_Value_Assertion", "2026-04-30 14:14:46", "FAILED"),
    ("07_Boundary_Value_Assertion", "2026-04-30 14:21:48", "FAILED"),
    ("07_Boundary_Value_Assertion", "2026-05-01 21:36:38", "FAILED"),
    ("07_Boundary_Value_Assertion", "2026-05-01 21:47:56", "FAILED"),
    # Scenario 08 - Always Failing
    ("08_Header_Assertion_Failure", "2026-04-25 16:03:31", "FAILED"),
    ("08_Header_Assertion_Failure", "2026-04-26 15:12:58", "FAILED"),
    ("08_Header_Assertion_Failure", "2026-04-26 15:57:06", "FAILED"),
    ("08_Header_Assertion_Failure", "2026-04-27 12:01:13", "FAILED"),
    ("08_Header_Assertion_Failure", "2026-04-27 12:33:59", "FAILED"),
    ("08_Header_Assertion_Failure", "2026-04-27 13:04:48", "FAILED"),
    ("08_Header_Assertion_Failure", "2026-04-30 14:14:47", "FAILED"),
    ("08_Header_Assertion_Failure", "2026-04-30 14:21:49", "FAILED"),
    ("08_Header_Assertion_Failure", "2026-05-01 21:36:39", "FAILED"),
    ("08_Header_Assertion_Failure", "2026-05-01 21:47:57", "FAILED"),
    # Scenario 09 - Always Failing
    ("09_Partial_Match_Failure", "2026-04-25 16:03:31", "FAILED"),
    ("09_Partial_Match_Failure", "2026-04-26 15:12:58", "FAILED"),
    ("09_Partial_Match_Failure", "2026-04-26 15:57:06", "FAILED"),
    ("09_Partial_Match_Failure", "2026-04-27 12:01:14", "FAILED"),
    ("09_Partial_Match_Failure", "2026-04-27 12:34:00", "FAILED"),
    ("09_Partial_Match_Failure", "2026-04-27 13:04:48", "FAILED"),
    ("09_Partial_Match_Failure", "2026-04-30 14:14:47", "FAILED"),
    ("09_Partial_Match_Failure", "2026-04-30 14:21:49", "FAILED"),
    ("09_Partial_Match_Failure", "2026-05-01 21:36:40", "FAILED"),
    ("09_Partial_Match_Failure", "2026-05-01 21:47:58", "FAILED"),
    # Scenario 10 - Always Failing
    ("10_Empty_Dataset_Assertion", "2026-04-25 16:03:31", "FAILED"),
    ("10_Empty_Dataset_Assertion", "2026-04-26 15:12:59", "FAILED"),
    ("10_Empty_Dataset_Assertion", "2026-04-26 15:57:07", "FAILED"),
    ("10_Empty_Dataset_Assertion", "2026-04-27 12:01:14", "FAILED"),
    ("10_Empty_Dataset_Assertion", "2026-04-27 12:34:00", "FAILED"),
    ("10_Empty_Dataset_Assertion", "2026-04-27 13:04:49", "FAILED"),
    ("10_Empty_Dataset_Assertion", "2026-04-30 14:14:47", "FAILED"),
    ("10_Empty_Dataset_Assertion", "2026-04-30 14:21:50", "FAILED"),
    ("10_Empty_Dataset_Assertion", "2026-05-01 21:36:41", "FAILED"),
    ("10_Empty_Dataset_Assertion", "2026-05-01 21:47:59", "FAILED"),
    # Scenario 12 - Always Failing
    ("12_Create_Resource_Schema_Failure_POST", "2026-04-25 16:03:33", "FAILED"),
    ("12_Create_Resource_Schema_Failure_POST", "2026-04-26 15:13:00", "FAILED"),
    ("12_Create_Resource_Schema_Failure_POST", "2026-04-26 15:57:08", "FAILED"),
    ("12_Create_Resource_Schema_Failure_POST", "2026-04-27 12:01:16", "FAILED"),
    ("12_Create_Resource_Schema_Failure_POST", "2026-04-27 12:34:01", "FAILED"),
    ("12_Create_Resource_Schema_Failure_POST", "2026-04-27 13:04:50", "FAILED"),
    ("12_Create_Resource_Schema_Failure_POST", "2026-04-30 14:14:48", "FAILED"),
    ("12_Create_Resource_Schema_Failure_POST", "2026-04-30 14:21:50", "FAILED"),
    ("12_Create_Resource_Schema_Failure_POST", "2026-05-01 21:36:42", "FAILED"),
    ("12_Create_Resource_Schema_Failure_POST", "2026-05-01 21:48:00", "FAILED"),
    # Scenario 13 - Flaky
    ("13_Delete_Resource_Success_DELETE", "2026-04-25 16:03:33", "PASSED"),
    ("13_Delete_Resource_Success_DELETE", "2026-04-26 15:13:01", "PASSED"),
    ("13_Delete_Resource_Success_DELETE", "2026-04-26 15:57:09", "PASSED"),
    ("13_Delete_Resource_Success_DELETE", "2026-04-27 12:01:17", "PASSED"),
    ("13_Delete_Resource_Success_DELETE", "2026-04-27 12:34:02", "PASSED"),
    ("13_Delete_Resource_Success_DELETE", "2026-04-27 13:04:51", "PASSED"),
    ("13_Delete_Resource_Success_DELETE", "2026-04-30 13:00:08", "FAILED"),
    ("13_Delete_Resource_Success_DELETE", "2026-04-30 14:14:45", "FAILED"),
    ("13_Delete_Resource_Success_DELETE", "2026-04-30 14:21:48", "PASSED"),
    ("13_Delete_Resource_Success_DELETE", "2026-05-01 21:36:37", "PASSED"),
    ("13_Delete_Resource_Success_DELETE", "2026-05-01 21:47:55", "FAILED"),
    # Always Passing scenarios
    ("01_Schema_Validation_Success", "2026-04-25 16:03:27", "PASSED"),
    ("01_Schema_Validation_Success", "2026-04-26 15:12:55", "PASSED"),
    ("01_Schema_Validation_Success", "2026-04-26 15:57:02", "PASSED"),
    ("01_Schema_Validation_Success", "2026-04-27 12:01:10", "PASSED"),
    ("01_Schema_Validation_Success", "2026-04-27 12:33:56", "PASSED"),
    ("01_Schema_Validation_Success", "2026-04-27 13:04:44", "PASSED"),
    ("01_Schema_Validation_Success", "2026-04-30 14:14:41", "PASSED"),
    ("01_Schema_Validation_Success", "2026-04-30 14:21:43", "PASSED"),
    ("01_Schema_Validation_Success", "2026-05-01 21:36:29", "PASSED"),
    ("01_Schema_Validation_Success", "2026-05-01 21:47:47", "PASSED"),
    ("02_List_Size_Assertion", "2026-04-25 16:03:28", "PASSED"),
    ("02_List_Size_Assertion", "2026-04-26 15:12:56", "PASSED"),
    ("02_List_Size_Assertion", "2026-04-26 15:57:03", "PASSED"),
    ("02_List_Size_Assertion", "2026-04-27 12:01:11", "PASSED"),
    ("02_List_Size_Assertion", "2026-04-27 12:33:56", "PASSED"),
    ("02_List_Size_Assertion", "2026-04-27 13:04:45", "PASSED"),
    ("02_List_Size_Assertion", "2026-04-30 14:14:42", "PASSED"),
    ("02_List_Size_Assertion", "2026-04-30 14:21:44", "PASSED"),
    ("02_List_Size_Assertion", "2026-05-01 21:36:31", "PASSED"),
    ("02_List_Size_Assertion", "2026-05-01 21:47:49", "PASSED"),
    ("03_Nested_Data_Assertion", "2026-04-25 16:03:29", "PASSED"),
    ("03_Nested_Data_Assertion", "2026-04-26 15:12:56", "PASSED"),
    ("03_Nested_Data_Assertion", "2026-04-26 15:57:04", "PASSED"),
    ("03_Nested_Data_Assertion", "2026-04-27 12:01:11", "PASSED"),
    ("03_Nested_Data_Assertion", "2026-04-27 12:33:57", "PASSED"),
    ("03_Nested_Data_Assertion", "2026-04-27 13:04:46", "PASSED"),
    ("03_Nested_Data_Assertion", "2026-04-30 14:14:42", "PASSED"),
    ("03_Nested_Data_Assertion", "2026-04-30 14:21:45", "PASSED"),
    ("03_Nested_Data_Assertion", "2026-05-01 21:36:32", "PASSED"),
    ("03_Nested_Data_Assertion", "2026-05-01 21:47:50", "PASSED"),
    ("06_Contains_Assertion_Failure", "2026-04-25 16:03:30", "PASSED"),
    ("06_Contains_Assertion_Failure", "2026-04-26 15:12:57", "PASSED"),
    ("06_Contains_Assertion_Failure", "2026-04-26 15:57:05", "PASSED"),
    ("06_Contains_Assertion_Failure", "2026-04-27 12:01:12", "PASSED"),
    ("06_Contains_Assertion_Failure", "2026-04-27 12:33:58", "PASSED"),
    ("06_Contains_Assertion_Failure", "2026-04-27 13:04:47", "PASSED"),
    ("06_Contains_Assertion_Failure", "2026-04-30 14:14:43", "PASSED"),
    ("06_Contains_Assertion_Failure", "2026-04-30 14:21:45", "PASSED"),
    ("06_Contains_Assertion_Failure", "2026-05-01 21:36:33", "PASSED"),
    ("06_Contains_Assertion_Failure", "2026-05-01 21:47:51", "PASSED"),
    ("11_Create_Resource_Success_POST", "2026-04-25 16:03:32", "PASSED"),
    ("11_Create_Resource_Success_POST", "2026-04-26 15:12:59", "PASSED"),
    ("11_Create_Resource_Success_POST", "2026-04-26 15:57:07", "PASSED"),
    ("11_Create_Resource_Success_POST", "2026-04-27 12:01:15", "PASSED"),
    ("11_Create_Resource_Success_POST", "2026-04-27 12:34:00", "PASSED"),
    ("11_Create_Resource_Success_POST", "2026-04-27 13:04:49", "PASSED"),
    ("11_Create_Resource_Success_POST", "2026-04-30 14:14:44", "PASSED"),
    ("11_Create_Resource_Success_POST", "2026-04-30 14:21:47", "PASSED"),
    ("11_Create_Resource_Success_POST", "2026-05-01 21:36:36", "PASSED"),
    ("11_Create_Resource_Success_POST", "2026-05-01 21:47:54", "PASSED"),
]

# --- Parse data ---
scenarios = defaultdict(list)
for name, ts, status in raw_data:
    dt = datetime.strptime(ts, '%Y-%m-%d %H:%M:%S')
    scenarios[name].append((dt, status))

for name in scenarios:
    scenarios[name].sort(key=lambda x: x[0])

# Classify scenarios
always_pass = []
always_fail = []
flaky = []
for name, runs in scenarios.items():
    statuses = set(s for _, s in runs)
    if statuses == {"PASSED"}:
        always_pass.append(name)
    elif statuses == {"FAILED"}:
        always_fail.append(name)
    else:
        flaky.append(name)

always_pass.sort()
always_fail.sort()
flaky.sort()

# ============================================================
# GRAPH 1: Failure count per scenario (bar chart)
# ============================================================
fig1, ax1 = plt.subplots(figsize=(14, 6))
all_names = sorted(scenarios.keys())
fail_counts = []
pass_counts = []
for name in all_names:
    runs = scenarios[name]
    fc = sum(1 for _, s in runs if s == "FAILED")
    pc = sum(1 for _, s in runs if s == "PASSED")
    fail_counts.append(fc)
    pass_counts.append(pc)

short_names = [n.split('_', 1)[0] for n in all_names]
x = range(len(all_names))
bars_pass = ax1.bar(x, pass_counts, color='#2ecc71', label='PASSED', width=0.6)
bars_fail = ax1.bar(x, fail_counts, bottom=pass_counts, color='#e74c3c', label='FAILED', width=0.6)

ax1.set_xlabel('Scenario', fontsize=11)
ax1.set_ylabel('Run Count', fontsize=11)
ax1.set_title('Karate Test Results: Pass vs Fail Count per Scenario', fontsize=13, fontweight='bold')
ax1.set_xticks(x)
ax1.set_xticklabels(short_names, rotation=45, ha='right', fontsize=9)
ax1.legend(loc='upper right')
ax1.grid(axis='y', alpha=0.3)
plt.tight_layout()
fig1.savefig('failure_pattern_bar.png', dpi=150)
print("Saved: failure_pattern_bar.png")

# ============================================================
# GRAPH 2: Timeline for flaky scenario (13_Delete)
# ============================================================
fig2, ax2 = plt.subplots(figsize=(14, 4))
for name in flaky:
    runs = scenarios[name]
    dates = [dt for dt, _ in runs]
    values = [1 if s == "PASSED" else 0 for _, s in runs]
    colors = ['#2ecc71' if v == 1 else '#e74c3c' for v in values]
    ax2.scatter(dates, [name.split('_', 1)[1].replace('_', ' ')] * len(dates),
                c=colors, s=120, zorder=5, edgecolors='white', linewidth=0.5)

ax2.set_title('Flaky Scenario Timeline: 13_Delete_Resource_Success_DELETE', fontsize=13, fontweight='bold')
ax2.set_xlabel('Execution Time', fontsize=11)
ax2.xaxis.set_major_formatter(mdates.DateFormatter('%b %d %H:%M'))
ax2.xaxis.set_major_locator(mdates.DayLocator())
plt.xticks(rotation=30, ha='right')
# Legend
from matplotlib.lines import Line2D
legend_elements = [
    Line2D([0], [0], marker='o', color='w', markerfacecolor='#2ecc71', markersize=10, label='PASSED'),
    Line2D([0], [0], marker='o', color='w', markerfacecolor='#e74c3c', markersize=10, label='FAILED'),
]
ax2.legend(handles=legend_elements, loc='upper left')
ax2.grid(axis='x', alpha=0.3)
plt.tight_layout()
fig2.savefig('flaky_scenario_timeline.png', dpi=150)
print("Saved: flaky_scenario_timeline.png")

# ============================================================
# GRAPH 3: Heatmap - scenario status over dates
# ============================================================
import numpy as np

all_dates = sorted(set(dt.strftime('%b %d') for name in scenarios for dt, _ in scenarios[name]))
scenario_names = sorted(scenarios.keys())

# Build matrix: for each scenario+date, compute ratio of failures
matrix = []
for name in scenario_names:
    row = []
    runs_by_date = defaultdict(list)
    for dt, status in scenarios[name]:
        runs_by_date[dt.strftime('%b %d')].append(status)
    for d in all_dates:
        if d in runs_by_date:
            fails = sum(1 for s in runs_by_date[d] if s == "FAILED")
            total = len(runs_by_date[d])
            row.append(fails / total)  # 0=all pass, 1=all fail
        else:
            row.append(-0.1)  # no data
    matrix.append(row)

matrix = np.array(matrix)

fig3, ax3 = plt.subplots(figsize=(14, 8))
from matplotlib.colors import ListedColormap, BoundaryNorm
cmap = ListedColormap(['#ecf0f1', '#2ecc71', '#f39c12', '#e74c3c'])
bounds = [-0.15, 0.0, 0.01, 0.5, 1.01]
norm = BoundaryNorm(bounds, cmap.N)

im = ax3.imshow(matrix, aspect='auto', cmap=cmap, norm=norm)
ax3.set_xticks(range(len(all_dates)))
ax3.set_xticklabels(all_dates, rotation=45, ha='right', fontsize=9)
short_scenario = [n.replace('_', ' ') for n in scenario_names]
ax3.set_yticks(range(len(scenario_names)))
ax3.set_yticklabels(short_scenario, fontsize=8)
ax3.set_title('Failure Heatmap: Scenario Status by Date', fontsize=13, fontweight='bold')
ax3.set_xlabel('Date', fontsize=11)
ax3.set_ylabel('Scenario', fontsize=11)

# Legend
from matplotlib.patches import Patch
legend_patches = [
    Patch(facecolor='#ecf0f1', edgecolor='gray', label='No Data'),
    Patch(facecolor='#2ecc71', edgecolor='gray', label='All Passed'),
    Patch(facecolor='#f39c12', edgecolor='gray', label='Mixed (Flaky)'),
    Patch(facecolor='#e74c3c', edgecolor='gray', label='All Failed'),
]
ax3.legend(handles=legend_patches, loc='upper right', fontsize=9)
plt.tight_layout()
fig3.savefig('failure_heatmap.png', dpi=150)
print("Saved: failure_heatmap.png")

print("\nAll graphs generated successfully!")
