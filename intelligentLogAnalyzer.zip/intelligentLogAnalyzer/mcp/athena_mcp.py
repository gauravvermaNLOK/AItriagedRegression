"""
Athena MCP Server for Karate Test Triage

Exposes an AWS Athena query tool via the Model Context Protocol (MCP),
allowing AI agents (e.g., Kiro) to run SQL queries against the
karate_logs table for automated test failure triage and analysis.

Usage:
    Configured as an MCP server in .kiro/settings/mcp.json.
    The agent calls the 'run_athena_query' tool with a SQL string.
"""

import boto3
import mcp.server.fastmcp as fastmcp
import re
import sys

# Initialize the MCP server with a descriptive name for tool discovery
mcp = fastmcp.FastMCP("athena-triage")

@mcp.tool()
def get_table_schema():
    """
    Retrieves the current schema for the Karate triage logs from AWS Glue.
    The AI should call this tool first to identify the correct table name
    and columns before generating any SQL queries.
    """
    client = boto3.client('glue')
    database_name = "karate_triage_db"

    try:
        # Use sys.stderr for logging to avoid crashing the MCP connection
        sys.stderr.write(f"[MCP] Fetching schema for database: {database_name}\n")

        # Get all tables in the database to find the one created by the crawler
        response = client.get_tables(DatabaseName=database_name)
        tables = response.get('TableList', [])

        if not tables:
            return f"No tables found in database '{database_name}'. Please ensure the crawler has run."

        # Format the schema information for the LLM
        schema_output = []
        for table in tables:
            table_name = table['Name']
            columns = [
                {"name": col['Name'], "type": col['Type']}
                for col in table.get('StorageDescriptor', {}).get('Columns', [])
            ]
            schema_output.append({
                "table_name": table_name,
                "description": f"Log data stored in S3 at {table.get('StorageDescriptor', {}).get('Location')}",
                "columns": columns
            })

        return str(schema_output)

    except Exception as e:
        sys.stderr.write(f"[MCP] Error fetching schema: {str(e)}\n")
        return f"Error retrieving schema: {str(e)}"

@mcp.tool()
def run_athena_query(query: str):
    """Run a SQL query against the karate_logs table in Athena."""
    client = boto3.client('athena')

#    # 1. Log what Kiro sent
#     print(f"\n[MCP] Incoming Query from Kiro: {query}")

#     # 2. THE FIX: Name Mapping & Limit Stripping
#     # Replace 'logs' or 'karate_logs' with 'raw_logs' (the folder-based name)
#     corrected_query = re.sub(r"\b(logs|raw_logs)\b", "karate_logs", query, flags=re.IGNORECASE)

#     # Strip the LIMIT to ensure full triage
#     modified_query = re.sub(r"LIMIT\s+\d+", "", corrected_query, flags=re.IGNORECASE).strip()

#     print(f"[MCP] Final Executed SQL: {modified_query}\n")

    # --- Athena Configuration ---
    # Database and S3 output location must match your Glue/Athena setup
    DATABASE = "karate_triage_db"
    OUTPUT = "s3://gaurav-logs-archive/athena-results/"

    # Submit the query to Athena for async execution
    response = client.start_query_execution(
        QueryString=query,
        QueryExecutionContext={'Database': DATABASE},
        ResultConfiguration={'OutputLocation': OUTPUT}
    )

    query_id = response['QueryExecutionId']

    # Poll until the query reaches a terminal state
    while True:
        status = client.get_query_execution(
            QueryExecutionId=query_id
        )['QueryExecution']['Status']['State']
        if status in ['SUCCEEDED', 'FAILED', 'CANCELLED']:
            break

    # Fetch and return results on success, otherwise report the failure status
    if status == 'SUCCEEDED':
        results = client.get_query_results(QueryExecutionId=query_id)
        return str(results['ResultSet']['Rows'])
    return f"Query failed with status: {status}"


if __name__ == "__main__":
    # Start the MCP server (stdio transport by default)
    mcp.run()
