Feature: Enterprise Bulk Triage - Assertion & Multi-Env POC

Background:
    * configure ssl = true
    * url 'https://jsonplaceholder.typicode.com'
    * def currentEnv = karate.properties['karate.env'] || 'uat'
    * print 'LOG_START | Environment:', currentEnv

  # --- SUCCESS SCENARIOS WITH ASSERTIONS ---

  Scenario: 01_Schema_Validation_Success
    Given path 'posts', 1
    When method get
    Then status 200
    # Validating data types (Schema Assertion)
    And match response == { id: '#number', title: '#string', body: '#string', userId: '#number' }
    # * print '--- RAW EVIDENCE ---'
    # * print 'Env:', currentEnv, '| Scenario: 01_Schema_Success | Status: PASS'

  Scenario: 02_List_Size_Assertion
    Given path 'users'
    When method get
    Then status 200
    # Asserting that the list contains exactly 10 users
    And match karate.sizeOf(response) == 10
    # * print '--- RAW EVIDENCE ---'
    # * print 'Env:', currentEnv, '| Scenario: 02_List_Size_Check | Status: PASS'

  Scenario: 03_Nested_Data_Assertion
    Given path 'users', 1
    When method get
    Then status 200
    # Asserting nested object values
    And match response.address.geo.lat == '#regex ^-?([1-8]?[1-9]|[1-9]0)\\.{1}\\d{1,6}'
    # * print '--- RAW EVIDENCE ---'
    # * print 'Env:', currentEnv, '| Scenario: 03_Nested_Geo_Assertion | Status: PASS'

   Scenario: 06_Contains_Assertion_Failure
    Given path 'posts'
    When method get
    Then status 200
    # Asserting that the list contains a specific title that doesn't exist
    And match response[*].title contains 'qui est esse'
    # * print '--- RAW EVIDENCE ---'
    # * print 'Env:', currentEnv, '| Scenario: 06_Content_Missing | Status: FAIL | Detail: Title not found in list'

  # --- FAILURE SCENARIOS (FOR AI TRIAGE TRAINING) ---

  Scenario: 04_Logic_Failure_Boolean_Mismatch
    Given path 'todos', 1
    When method get
    Then status 200
    # Intentionally failing: Most placeholder todos are false
    And match response.completed == true
    # * print '--- RAW EVIDENCE ---'
    # * print 'Env:', currentEnv, '| Scenario: 04_Boolean_Mismatch | Status: FAIL | Detail: Expected true but got false'

  Scenario: 05_Schema_Drift_Failure
    Given path 'posts', 1
    When method get
    Then status 200
    # Simulating a schema change (Asserting 'userId' should be a string, but it's a number)
    And match response.userId == '#string'
    # * print '--- RAW EVIDENCE ---'
    # * print 'Env:', currentEnv, '| Scenario: 05_Schema_Drift | Status: FAIL | Detail: Type Mismatch'