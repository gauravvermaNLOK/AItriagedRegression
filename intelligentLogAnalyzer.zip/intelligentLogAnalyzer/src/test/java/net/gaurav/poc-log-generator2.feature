Feature: Enterprise Bulk Triage - Assertion & Multi-Env POC

Background:
    * configure ssl = true
    * url 'https://jsonplaceholder.typicode.com'
    * def currentEnv = karate.properties['karate.env'] || 'uat'
    * print 'LOG_START | Environment:', currentEnv

  # --- SUCCESS SCENARIOS WITH ASSERTIONS ---
  Scenario: 11_Create_Resource_Success_POST
    Given path 'posts'
    And request { title: 'Triage Test', body: 'Testing log ingestion', userId: 101 }
    When method post
    Then status 201
    And match response == { id: '#number', title: 'Triage Test', body: 'Testing log ingestion', userId: 101 }

  Scenario: 13_Delete_Resource_Success_DELETE
    Given path 'posts', 1
    When method delete
    Then status 400

  # --- FAILED SCENARIOS WITH ASSERTIONS ---

  Scenario: 07_Boundary_Value_Assertion
    Given path 'posts', 1
    When method get
    Then status 200
    # Asserting the ID is greater than 100 (it's actually 1)
    And assert response.id > 100
    # * print '--- RAW EVIDENCE ---'
    # * print 'Env:', currentEnv, '| Scenario: 07_Boundary_Failure | Status: FAIL | Detail: ID outside expected range'

  Scenario: 08_Header_Assertion_Failure
    Given path 'users', 1
    When method get
    Then status 200
    # Asserting a header value that is usually different (e.g., Content-Encoding)
    And match header Content-Type contains 'application/xml'
    # * print '--- RAW EVIDENCE ---'
    # * print 'Env:', currentEnv, '| Scenario: 08_Header_Mismatch | Status: FAIL | Detail: Expected XML but got JSON'

  Scenario: 09_Partial_Match_Failure
    Given path 'users', 1
    When method get
    Then status 200
    # Asserting the user's name starts with 'Mrs.' (it's 'Leanne Graham')
    And match response.name == '#regex ^Mrs\\..*'
    # * print '--- RAW EVIDENCE ---'
    # * print 'Env:', currentEnv, '| Scenario: 09_Prefix_Mismatch | Status: FAIL | Detail: Regex mismatch'

  Scenario: 10_Empty_Dataset_Assertion
    # Simulating a search that should return results but doesn't
    Given path 'comments'
    And param postId = 9999
    When method get
    Then status 200
    And match response == '#[]? _.length > 0'
    # * print '--- RAW EVIDENCE ---'
    # * print 'Env:', currentEnv, '| Scenario: 10_Empty_Data_Failure | Status: FAIL | Detail: Expected records but got empty list'


  Scenario: 12_Create_Resource_Schema_Failure_POST
    Given path 'posts'
    # Intentional failure: sending body as a string instead of object to check triage
    And request 'invalid request format'
    When method post
    Then status 201
    # This might pass the API but fail your match logic if the API returns a default object
    And match response.title == '#present'