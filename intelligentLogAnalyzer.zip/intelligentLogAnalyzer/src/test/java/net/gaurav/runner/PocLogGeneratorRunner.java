package net.gaurav.runner;

import com.intuit.karate.junit5.Karate;

/**
 * Karate test runner for the POC Log Generator feature files.
 *
 * Executes all scenarios from poc-log-generator1 and poc-log-generator2
 * against the configured environment (passed via -Dkarate.env, defaults to 'uat').
 *
 * Usage:
 *   mvn test -Dtest=net.gaurav.runner.PocLogGeneratorRunner -Dkarate.env=dev
 *
 * Reports are generated at: target/karate-reports/
 */
class PocLogGeneratorRunner {

    @Karate.Test
    Karate testAll() {
        // Run both feature files using classpath references
        // Feature files are located at: src/test/java/net/gaurav/
        return Karate.run(
            "classpath:net/gaurav/poc-log-generator1.feature",
            "classpath:net/gaurav/poc-log-generator2.feature"
        );
    }
}
