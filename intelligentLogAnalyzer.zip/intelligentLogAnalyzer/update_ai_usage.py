"""
Updates MyAIUsage.xlsx with today's Kiro session data.
Creates the file with headers if it doesn't exist.
Updates existing row if today's date is already present.
"""

import os
from datetime import datetime
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill

FILE_PATH = "MyAIUsage.xlsx"
TODAY = datetime.now().strftime("%d-%m-%Y")

# --- Today's session data ---
data = {
    "Date": TODAY,
    "AI Name": "Kiro",
    "Coding Hours": 1.5,
    "Reference Hours": 0.5,
    "Time Saved": "1.0 hrs (~50% reduction)",
    "Efficiency %": "50%",
    "Category": "Testing, DevOps, Refactoring",
    "Lines of Code by AI": 45,
    "Lines of Code Manual": 5,
    "Work Done": (
        "• Ran karate_s3_ingestor.py to flatten & upload 3 report files to S3\n"
        "• Queried Athena for all failed scenarios with count & environment\n"
        "• Cross-referenced response data with feature assertions for failure root causes\n"
        "• Moved PocLogGeneratorRunner.java into runner/ folder, updated package & classpath\n"
        "• Parameterized feature files to accept environment via -Dkarate.env\n"
        "• Ran Karate tests in dev environment via runner class\n"
        "• Moved flattener & ingestor to util/, athena_mcp to mcp/\n"
        "• Fixed REPORTS_DIR path resolution in ingestor for new folder structure\n"
        "• Updated hook, README, and MCP config references for new paths\n"
        "• Added Javadoc comments to PocLogGeneratorRunner\n"
        "• Added mvn command for running specific feature files to README"
    ),
}

HEADERS = [
    "Date", "AI Name", "Coding Hours", "Reference Hours",
    "Time Saved", "Efficiency %", "Category",
    "Lines of Code by AI", "Lines of Code Manual", "Work Done"
]

thin_border = Border(
    left=Side(style="thin"),
    right=Side(style="thin"),
    top=Side(style="thin"),
    bottom=Side(style="thin"),
)
header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
header_font = Font(bold=True, color="FFFFFF", size=11)
cell_font = Font(size=11)
wrap_alignment = Alignment(wrap_text=True, vertical="top")


def style_header(ws):
    for col_idx, header in enumerate(HEADERS, 1):
        cell = ws.cell(row=1, column=col_idx, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.border = thin_border
        cell.alignment = Alignment(horizontal="center", vertical="center")


def write_row(ws, row_num, data_dict):
    for col_idx, header in enumerate(HEADERS, 1):
        cell = ws.cell(row=row_num, column=col_idx, value=data_dict.get(header, ""))
        cell.font = cell_font
        cell.border = thin_border
        cell.alignment = wrap_alignment


def auto_width(ws):
    for col_idx, header in enumerate(HEADERS, 1):
        if header == "Work Done":
            ws.column_dimensions[ws.cell(row=1, column=col_idx).column_letter].width = 70
        else:
            ws.column_dimensions[ws.cell(row=1, column=col_idx).column_letter].width = max(len(header) + 4, 16)


if os.path.exists(FILE_PATH):
    wb = load_workbook(FILE_PATH)
    ws = wb.active
    # Check if today's date already exists
    existing_row = None
    for row in range(2, ws.max_row + 1):
        if ws.cell(row=row, column=1).value == TODAY:
            existing_row = row
            break
    if existing_row:
        write_row(ws, existing_row, data)
        print(f"Updated existing row for {TODAY}")
    else:
        new_row = ws.max_row + 1
        write_row(ws, new_row, data)
        print(f"Added new row for {TODAY}")
else:
    wb = Workbook()
    ws = wb.active
    ws.title = "AI Usage Log"
    style_header(ws)
    write_row(ws, 2, data)
    print(f"Created new file with entry for {TODAY}")

auto_width(ws)
wb.save(FILE_PATH)
print(f"Saved to {FILE_PATH}")
