"""
Karate Test Report Ingestion Module

Parses Karate JSON test reports and flattens them into a structured CSV format
suitable for downstream triage, analytics, and AI-based failure classification.

Input:  Karate JSON report (e.g., target/karate-reports/*.karate-json.txt)
Output: Flattened CSV with one row per scenario, including HTTP details and pass/fail status.
"""

import json
import re
import pandas as pd
import os
from datetime import datetime


def extract_http_info(step_log):
    """
    Parses a single Karate step log to extract HTTP request/response details.

    Karate logs HTTP wire data in a specific format:
        - Request lines are prefixed with '1 >' (e.g., '1 > GET https://...')
        - Response lines are prefixed with '1 <' (e.g., '1 < 200')
        - Request body appears between the last '>' header line and 'response time'
        - Response body appears after the last '<' header line

    Args:
        step_log (str): Raw log output from a single Karate step.

    Returns:
        dict: Extracted HTTP details with keys:
            - method (str):           HTTP method (GET, POST, etc.) or 'N/A'
            - url (str):              Request URL or 'N/A'
            - request_payload (str):  Request body, if present
            - response_payload (str): Response body, if present
    """
    details = {
        "method": "N/A",
        "url": "N/A",
        "request_payload": "",
        "response_payload": ""
    }

    if not step_log:
        return details

    # --- Extract HTTP Method and URL ---
    # Matches lines like: '1 > GET https://jsonplaceholder.typicode.com/posts/1'
    # Regex breakdown:
    #   ^\d+\s*>        — line starts with a number followed by '>' (Karate wire log prefix)
    #   \s*(GET|POST|PUT|DELETE|PATCH)  — captures the HTTP method
    #   \s+(https?://\S+)              — captures the full URL (http or https, no spaces)
    request_match = re.search(
        r"^\d+\s*>\s*(GET|POST|PUT|DELETE|PATCH)\s+(https?://\S+)",
        step_log,
        re.MULTILINE
    )
    if request_match:
        details["method"] = request_match.group(1)
        details["url"] = request_match.group(2)

    # --- Extract Request Payload ---
    # The request body sits between the last '>' header line and the 'response time' marker.
    if " > " in step_log:
        try:
            lines = step_log.split('\n')
            body_start = -1
            body_end = -1

            for i, line in enumerate(lines):
                # Track the last request header line (body starts after it)
                if line.startswith('1 > ') or line.startswith('> '):
                    body_start = i + 1
                # The response timing marker signals the end of the request body
                if 'response time in milliseconds' in line:
                    body_end = i
                    break

            if body_start != -1 and body_end != -1:
                req_body = "\n".join(lines[body_start:body_end]).strip()
                details["request_payload"] = req_body
        except Exception:
            pass  # Gracefully skip malformed log sections

    # --- Extract Response Payload ---
    # The response body appears after the last '<' header line through end of log.
    if "1 < " in step_log or " < " in step_log:
        try:
            lines = step_log.split('\n')
            res_start = -1

            for i, line in enumerate(lines):
                # Track the last response header line (body starts after it)
                if line.startswith('1 < ') or line.startswith('< '):
                    res_start = i + 1

            if res_start != -1:
                res_body = "\n".join(lines[res_start:]).strip()
                details["response_payload"] = res_body
        except Exception:
            pass  # Gracefully skip malformed log sections

    return details


def process_karate_report(input_json, output_csv):
    """
    Reads a Karate JSON report, flattens each scenario into a single row,
    and writes the results to a CSV file.

    Each row captures:
        - Execution timestamp
        - Scenario name and environment
        - HTTP method, URL, request/response payloads
        - Pass/Fail status

    The environment is extracted from a custom Karate print statement:
        * print 'LOG_START | Environment:', currentEnv

    Args:
        input_json (str): Path to the Karate JSON report file.
        output_csv (str):  Path for the output CSV file.

    Returns:
        list[dict]: The flattened data rows, or None if the input file is missing.
    """
    if not os.path.exists(input_json):
        print(f"Error: File {input_json} not found.")
        return

    with open(input_json, 'r') as f:
        data = json.load(f)

    flattened_data = []

    for scenario in data.get('scenarioResults', []):
        # --- Scenario-level metadata ---
        scenario_name = scenario.get('name', 'Unnamed Scenario')
        status = "FAILED" if scenario.get('failed') else "PASSED"
        timestamp = datetime.fromtimestamp(
            scenario.get('startTime', 0) / 1000
        ).strftime('%Y-%m-%d %H:%M:%S')

        env = "unknown"
        http_data = {
            "method": "N/A",
            "url": "N/A",
            "request_payload": "",
            "response_payload": ""
        }

        # --- Walk through each step to extract environment and HTTP wire data ---
        for step in scenario.get('stepResults', []):
            log = step.get('stepLog', '')

            # Capture environment from the custom LOG_START print statement
            if 'LOG_START' in log:
                env_match = re.search(r"Environment:\s*(\w+)", log)
                if env_match:
                    env = env_match.group(1)

            # Capture HTTP details from steps that contain full wire logs
            # (both request '>' and response '<' markers must be present)
            if ' > ' in log and ' < ' in log:
                extracted = extract_http_info(log)
                if extracted["method"] != "N/A":
                    http_data = extracted

        # --- Build the flattened row for this scenario ---
        flattened_data.append({
            "execution_time": timestamp,
            "scenario_name": scenario_name,
            "environment": env,
            "http_method": http_data["method"],
            "url": http_data["url"],
            "request_body": http_data["request_payload"],
            "response_body": http_data["response_payload"],
            "status": status
        })

    # --- Write results to CSV ---
    df = pd.DataFrame(flattened_data)
    df.to_csv(output_csv, index=False)
    print(f"File successfully flattened to: {output_csv}")
    return flattened_data


# --- CONFIGURATION ---
# Uncomment below to run as a standalone script.
#
# INPUT_FILE = 'target/karate-reports/src.test.java.net.charter.poc-log-generator.karate-json.txt'
# OUTPUT_FILE = 'karate_triage_flattened.csv'
#
# if __name__ == "__main__":
#     process_karate_report(INPUT_FILE, OUTPUT_FILE)
