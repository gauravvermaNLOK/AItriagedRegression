"""
Karate Test Report S3 Ingestion Module

Takes the flattened Karate test results (produced by karate_report_flattener.py)
and uploads them to S3 in JSONL (JSON Lines) format for downstream consumption
by Athena, Glue, or other analytics services.

Pipeline: Karate JSON Report -> Flattener (CSV + dict list) -> This module -> S3 (JSONL)
"""

import json
import boto3
import io
import os
import sys
import glob
from datetime import datetime

# Resolve project root (one level up from this script's directory)
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Import the flattening function from the report flattener module
from karate_report_flattener import process_karate_report


def ingest_to_s3_jsonl(flattened_data, bucket_name, folder_name):
    """
    Converts flattened Karate test results to JSONL format and uploads to S3.

    JSONL (JSON Lines) stores one JSON object per line, making it ideal for
    streaming ingestion by AWS Athena, Glue crawlers, and Spark jobs.

    Args:
        flattened_data (list[dict]): List of scenario result dicts from process_karate_report().
        bucket_name (str):           Target S3 bucket name.
        folder_name (str):           S3 key prefix (folder) for organizing uploaded files.

    Uploads to: s3://{bucket_name}/{folder_name}/karate_logs_{timestamp}.jsonl
    """
    s3_client = boto3.client('s3')

    # Serialize each scenario result as a single JSON line
    jsonl_buffer = io.StringIO()
    for entry in flattened_data:
        json.dump(entry, jsonl_buffer)
        jsonl_buffer.write('\n')

    # Generate a unique S3 key using the current timestamp to avoid overwrites
    file_timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    file_key = f"{folder_name}/karate_logs_{file_timestamp}.jsonl"

    try:
        s3_client.put_object(
            Bucket=bucket_name,
            Key=file_key,
            Body=jsonl_buffer.getvalue(),
            ContentType='application/x-jsonlines'
        )
        print(f"Successfully ingested data to s3://{bucket_name}/{file_key}")
    except Exception as e:
        print(f"Error uploading to S3: {e}")


if __name__ == "__main__":
    # --- Configuration ---
    REPORTS_DIR = os.path.join(PROJECT_ROOT, 'target', 'karate-reports')
    BUCKET = 'gaurav-logs-archive'
    FOLDER = 'raw_logs'

    # If a specific file is passed as a CLI argument, process just that file.
    # Otherwise, auto-discover all *karate-json.txt files in the reports directory.
    if len(sys.argv) > 1:
        input_files = [sys.argv[1]]
    else:
        input_files = glob.glob(f"{REPORTS_DIR}/*karate-json.txt")

    if not input_files:
        print(f"No *karate-json.txt files found in {REPORTS_DIR}")
        sys.exit(1)

    for input_file in input_files:
        print(f"Processing: {input_file}")
        # Derive CSV output name from the input filename
        output_csv = input_file.replace('.txt', '.csv')

        # Step 1: Flatten the Karate JSON report into structured rows
        results = process_karate_report(input_file, output_csv)

        # Step 2: Upload the flattened results to S3 as JSONL
        if results:
            ingest_to_s3_jsonl(results, BUCKET, FOLDER)
